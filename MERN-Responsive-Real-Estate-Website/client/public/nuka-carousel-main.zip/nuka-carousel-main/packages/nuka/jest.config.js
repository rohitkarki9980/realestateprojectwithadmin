module.exports = {
  setupFilesAfterEnv: ['<rootDir>/jest-setup.ts'],
};
