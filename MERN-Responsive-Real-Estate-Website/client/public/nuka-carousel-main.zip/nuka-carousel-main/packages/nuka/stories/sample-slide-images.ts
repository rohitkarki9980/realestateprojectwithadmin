/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
// TypeScript is disabled for this single-purpose file because we would
// otherwise need to set a global type declaration for *.png files, which in a
// worst-case scenario might screw up the environment of someone using our
// library.

import slide1Image from './images/1.png';
import slide2Image from './images/2.png';
import slide3Image from './images/3.png';
import slide4Image from './images/4.png';
import slide5Image from './images/5.png';
import slide6Image from './images/6.png';
import slide7Image from './images/7.png';
import slide8Image from './images/8.png';
import slide9Image from './images/9.png';
import slide10Image from './images/10.png';
import slide11Image from './images/11.png';
import slide12Image from './images/12.png';
import slide13Image from './images/13.png';
import slide14Image from './images/14.png';

export const sampleSlideImageSources = [
  slide1Image,
  slide2Image,
  slide3Image,
  slide4Image,
  slide5Image,
  slide6Image,
  slide7Image,
  slide8Image,
  slide9Image,
  slide10Image,
  slide11Image,
  slide12Image,
  slide13Image,
  slide14Image,
];
