module.exports = {
  singleQuote: true,
};
